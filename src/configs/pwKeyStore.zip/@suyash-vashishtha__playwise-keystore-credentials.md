# Android Keystore Credentials

These credentials are used in conjunction with your Android keystore file to sign your app for distribution. 

## Credential Values

- Android keystore password: 6c04d51d81be494497717438a9af50fd
- Android key alias: QHN1eWFzaC12YXNoaXNodGhhL3BsYXl3aXNl
- Android key password: 9c46e0644d3a4c02a8283d4ccf4817bf
      